<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	private $data;

	 function __construct()
    {
      parent::__construct();
      $this->load->model('AdminModel');
      $this->data['title_bar'] = $this->data['title']= 'Espace Admin';
    }

    public function index()
    {
      if($this->session->userdata("infoUser"))
      {
        redirect(site_url('admin/dashbord'), 'refresh');
      }
      if(isset($_POST['btn-connexion']))
      {
        //var_dump($_POST); die;

        if(!empty($_POST['login']) && !empty($_POST['pwd']))
        {
           $infoUser = $this->AdminModel->verifUser($_POST['login'], $_POST['pwd']);
          
          if($infoUser)
          {
              $this->session->set_userdata('infoUser',$infoUser);
              redirect(site_url('admin/dashbord'), 'refresh');
          }
        }else
        {
          $this->session->set_flashdata('error','Remplir tous les champs svp');
        }
      }
      $this->load->view('login', $this->data);
    }

    public function dashbord()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }
      $this->data['title'] = 'Tableau de bord';
      $this->load->view('layout' , $this->data);
      $this->load->view('tableau_bord', $this->data);
      $this->load->view('footer');
    }

    public function addthemes()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }

      $this->data['categories'] = $this->AdminModel->selectCAtegories();

      if($this->input->post('submit'))
      {
        if (empty($this->input->post('nom_template')) or
            empty($this->input->post('lien_demo')) or
            empty($this->input->post('categori')) or
            empty($_FILES['image_site']['name']))
        {
          $this->session->set_flashdata('error', 'Tous les champs sont obligatoire');
        }elseif($this->AdminModel->selectSites($this->input->post('nom_template')) !== false){
           $this->session->set_flashdata('error', "Un thème porte déjà le nom : ".$this->input->post('nom_template'));
        }else
        {
           $traiteImg = $this->gestionImage('image_site', $this->input->post('nom_template'));
           if($traiteImg === false)
           {
              $this->session->set_flashdata('error', "Vous n'avez pas choisir d'image...");
           }else if($traiteImg === -1)
           {
              $this->session->set_flashdata('error', "Impossible de charger cette image !!!");
           }else if($traiteImg === -2)
           {
              $this->session->set_flashdata('error', "Image trop lourde !!!");
           }else
           {
             $data = array(
                        'nom_template'=>$this->input->post('nom_template'),
                        'lien_demo'=>$this->input->post('lien_demo'),
                        'categori'=>$this->input->post('categori'),
                        'image_site'=>$traiteImg,
                        'date_create'=>time(),
                    );
               $this->AdminModel->saveOperation("sites", $data);
               $this->session->set_flashdata('successMessage', 'Thème enregistré avec succès');
               redirect(base_url('admin/listsites'), 'refresh');
           }
        }
      }
      $this->data['title'] = 'Ajouter un thème';
      $this->load->view('layout' , $this->data);
      $this->load->view('ajout_site', $this->data);
      $this->load->view('footer');
    }

   public function addcategorie()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }

      var_dump($this->data['categories'] = $this->AdminModel->selectCAtegories('test'));die;

      if($this->input->post('submit'))
      {
        $lib = $this->AdminModel->selectCAtegories($this->input->post('libelle'));
        if (empty($this->input->post('libelle')))
        {
          $this->session->set_flashdata('error', 'Tous les champs sont obligatoire');
        }elseif((is_array($lib) && count($lib)!=0))
        {
           $this->session->set_flashdata('error', "Une catégorie porte déjà le nom : ".$this->input->post('libelle'));
        }else
        {
             $data = array(
                        'libelle'=>$this->input->post('libelle'),
                        'date_create'=>time(),
                    );
               $this->AdminModel->saveOperation("categories", $data);
               $this->session->set_flashdata('successMessage', 'Catégorie enregistré avec succès');
               redirect(base_url('admin/listecategorie'), 'refresh');
        }
      }
      $this->data['title'] = "Ajout des catégories";
      $this->load->view('layout' , $this->data);
      $this->load->view('addcategorie', $this->data);
      $this->load->view('footer');
    }
    public function listsites()
    {
      $this->data['title'] = 'Liste des thèmes enregistrés';
      $this->load->view('layout' , $this->data);
      $this->load->view('listetheme', $this->data);
      $this->load->view('footer');
    }

    private function gestionImage($name_img, $sitename)
    {
          if(!empty($_FILES[$name_img]['name']))
          {
              $crypt = $sitename.date("d");
              $config['image_type'] = strtolower(pathinfo($_FILES[$name_img]['name'],PATHINFO_EXTENSION));
              $config['file_name'] = $crypt.'.'.$config['image_type'];
              $config['upload_path'] = './assets/uploads/files/';
              $config['allowed_types']        = 'jpeg|jpg|png';
              $this->load->library('upload', $config);
              $data['file_size'] = $_FILES[$name_img]['size'];
              if(!$this->upload->do_upload($name_img))
              {
                return -1;
              }elseif($data['file_size'] > 2048000)
              {
                return -2;
              }else
              {
                $data =  $this->upload->data();
                $photo = $data['file_name'];
                return $photo;
              }

          }else
          {
             return false;
          }
    }


    public function logout()
    {
        $authentif = $this->session->userdata("infoUser");
        unset($_SESSION['infoUser']);
        redirect(site_url(), 'refresh');
    }
}
