<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Recensement extends CI_Controller {

	private $data;

	function __construct()
    {
      parent::__construct();
      $this->load->model('RecensementModel');
      $this->data['title']= 'Recensement';
      $this->data['title_bar']= 'Recensement et immatriculation';
      $this->data['fonctions']=$this->RecensementModel->selectEnumeration();
      $this->data['region']=$this->RecensementModel->selectEnumeration('region_membre');
      $this->data['departement']=$this->RecensementModel->selectEnumeration('departement_membre');
      $this->data['zone']=$this->RecensementModel->selectEnumeration('zone_membre');
      $this->data['section']=$this->RecensementModel->selectEnumeration('section');
      $this->data['localite']=$this->RecensementModel->selectEnumeration('localite_membre');
      $this->data['comiter']=$this->RecensementModel->selectEnumeration('nom_comite_base');
      $this->data['i']= 0;
    }

    public function index()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }
      
      if(isset($_GET['region']) && isset($_GET['departement']) && isset($_GET['ss_zone']) && isset($_GET['localite']) && isset($_GET['nom_section']) && isset($_GET['nom_comite']))
      {  
         $region = $_GET['region'];
         $departement = $_GET['departement'];
         $ss_zone = $_GET['ss_zone'];
         $localite = $_GET['localite'];
         $nom_section = $_GET['nom_section'];
         $nom_comite = $_GET['nom_comite'];
         $this->data['listMembre']= $this->RecensementModel->selectMembre($region, $departement, $ss_zone, $localite, $nom_section, $nom_comite);
         
         if(count($this->data['listMembre']))
         {
             $this->data['i']= 1;
         }
        //var_dump(count($this->data['listMembre']));die;
          
      }else
      {
            $this->data['listMembre']= array();
           // $this->RecensementModel->selectMembre();
         // $this->data['i']= 0;
      }
      
      $this->load->view('layout' , $this->data);
      $this->load->view('liste_membre', $this->data);
      $this->load->view('footer');
    }

    public function ajouter()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }
      $this->data['title_bar']= 'Ajout d\'un nouveau membre';

      /*$this->data['fonctions']=$this->RecensementModel->selectEnumeration();
      $this->data['region']=$this->RecensementModel->selectEnumeration('region_membre');
      $this->data['departement']=$this->RecensementModel->selectEnumeration('departement_membre');
      $this->data['zone']=$this->RecensementModel->selectEnumeration('zone_membre');
      $this->data['section']=$this->RecensementModel->selectEnumeration('section');
      $this->data['localite']=$this->RecensementModel->selectEnumeration('localite_membre');
      $this->data['comiter']=$this->RecensementModel->selectEnumeration('nom_comite_base');*/
      if($this->input->post('save'))
      {

        //var_dump($this->input->post()); die;
        if (empty($this->input->post('departement')) or
            empty($this->input->post('ss_zone')) or
            empty($this->input->post('localite')) or
            empty($this->input->post('type_membre')) or
            //empty($this->input->post('num_carte_militant')) or
           // empty($this->input->post('concat')) or
            empty($this->input->post('region')) or
            empty($this->input->post('nom')) or
            empty($this->input->post('prenom')) or
            empty($this->input->post('sexe')) or
            empty($this->input->post('date_n')) or
            empty($this->input->post('fonction')) or
            empty($this->input->post('num_pieces')))
        {
          $this->session->set_flashdata('errorMessage', 'Tous les champs sont obligatoire');
        }elseif(empty($this->input->post('nom_section')) and empty($this->input->post('nom_comite')))
        {
          $this->session->set_flashdata('errorMessage', 'Tous les champs sont obligatoire');
        }elseif(!empty($this->input->post('concat')) and !is_numeric($this->input->post('concat')))
        {
          $this->session->set_flashdata('errorMessage', 'Contact invalide');
        }else
        {
          $data = array(
                        'region_membre'=>$this->input->post('region'),
                        'departement_membre'=>$this->input->post('departement'),
                        'zone_membre'=>$this->input->post('ss_zone'),
                        'localite_membre'=>$this->input->post('localite'),
                        'type_membre'=>$this->input->post('type_membre'),
                        'section'=>$this->input->post('nom_section'),
                        'nom_comite_base'=>$this->input->post('nom_comite'),
                        'nom'=>$this->input->post('nom'),
                        'prenoms'=>$this->input->post('prenom'),
                        'date_naissance'=>$this->input->post('date_n'),
                        'sexe'=>$this->input->post('sexe'),
                        'fonction'=>$this->input->post('fonction'),
                        'numero_pieces'=>$this->input->post('num_pieces'),
                        'numero_carte_militante'=>$this->input->post('num_carte_militant'),
                        'contact'=>$this->input->post('concat'),
                    );
         $this->RecensementModel->saveOperation("membres", $data);
         $this->session->set_flashdata('successMessage', 'Membre enregistré avec succès');
         redirect(base_url('recensement'), 'refresh');
         
        }

      }
      $this->load->view('layout' , $this->data);
      $this->load->view('ajouter_membre', $this->data);
      $this->load->view('footer');
    }


    public function delete()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }

      $id = $this->uri->segment(3);
      //var_dump($id);
      if($id == 0 or $id==null)
      {
        show_404();
      }
      if($this->RecensementModel->deleteMembre($id))
      {
        $this->session->set_flashdata('successMessage', 'Membre supprimé avec succès');
         redirect(base_url('recensement'), 'refresh');
      }


    }
    
    
    
    public function get_departement()
	{
		//reccuperation de la region envoyé par ajax
		$region = $this->input->post('region_id');
		
		//var_dump($region);die;

		$departs = $this->RecensementModel->get_departement_query($region);

		if(count($departs)>0)
		{
			$tag_select = '';
			$tag_select .= '<option value="">Selectionner un departement</option>';

			foreach($departs as $depart)
			{
			    $selected = ''; 
                if(isset($_GET['departement']) && $_GET['departement'] == $depart->departement_membre)
                {$selected = 'selected';}
				$tag_select .= '<option value="'.$depart->departement_membre.'" '.$selected.' >'.$depart->departement_membre.'</option>';
			}

			echo json_encode($tag_select);
		}
	}
	
	public function get_zone()
	{
		//reccuperation de la region envoyé par ajax
		$departement = $this->input->post('departement_id');
		
		//var_dump($region);die;

		$zones = $this->RecensementModel->get_zone_query($departement);

		if(count($zones)>0)
		{
			$tag_select = '';
			$tag_select .= '<option value="">Selectionner une zone</option>';

			foreach($zones as $zone)
			{
				$tag_select .= '<option value="'.$zone->zone_membre.'">'.$zone->zone_membre.'</option>';
			}

			echo json_encode($tag_select);
		}
	}
	
	public function get_localite()
	{
		//reccuperation de la region envoyé par ajax
		$zone = $this->input->post('zone_id');
		
		//var_dump($region);die;

		$localites = $this->RecensementModel->get_localite_query($zone);

		if(count($localites)>0)
		{
			$tag_select = '';
			$tag_select .= '<option value="">Selectionner une localite</option>';

			foreach($localites as $localite)
			{
				$tag_select .= '<option value="'.$localite->localite_membre.'">'.$localite->localite_membre.'</option>';
			}

			echo json_encode($tag_select);
		}
	}
	
	public function get_section()
	{
		//reccuperation de la region envoyé par ajax
		$localite = $this->input->post('localite_id');
		
		//var_dump($region);die;

		$sections = $this->RecensementModel->get_section_query($localite);

		if(count($sections)>0)
		{
			$tag_select = '';
			$tag_select .= '<option value="">Selectionner une section</option>';

			foreach($sections as $section)
			{
				$tag_select .= '<option value="'.$section->section.'">'.$section->section.'</option>';
			}

			echo json_encode($tag_select);
		}
	}
	
	public function get_comite()
	{
		//reccuperation de la region envoyé par ajax
		$section = $this->input->post('section_id');
		
		//var_dump($region);die;

		$comites = $this->RecensementModel->get_comiter_query($section);

		if(count($comites)>0)
		{
			$tag_select = '';
			$tag_select .= '<option value="">Selectionner un comite</option>';

			foreach($comites as $comite)
			{
			    $selected = ''; 
                if(isset($_GET['nom_comite']) && $_GET['nom_comite'] == $comite->nom_comite_base)
                {$selected = 'selected';}
				$tag_select .= '<option value="'.$comite->nom_comite_base.'" '.$selected.' >'.$comite->nom_comite_base.'</option>';
			}

			echo json_encode($tag_select);
		}
	}
	


}

