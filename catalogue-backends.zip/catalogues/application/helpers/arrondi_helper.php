<?php
defined('BASEPATH') OR exit('No direct script access allowed');


if (!function_exists('Arrondi'))
{
      function Arrondi($float)
      {
        $virgule = explode(".", $float);
        if(isset($virgule[1]))
        {
          $apers_virgule = substr($virgule[1], 2, 1);
          $i = substr($virgule[1], 0, 2);
            if($apers_virgule > 5)
          {
           $i = $i + 1;
          }
          $float = $virgule[0].'.'.$i;
        }

        return $float;

      }
}
