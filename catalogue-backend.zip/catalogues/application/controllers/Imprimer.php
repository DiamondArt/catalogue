<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Imprimer extends CI_Controller
{

	private $data;

	  function __construct()
    {
      parent::__construct();
      $this->load->library('Pdf');
      $this->load->model('RecensementModel');
      
    }

    /*public function index()
    {
      $i=0;
      while ($i<= 100)
      {

        $data = array(
              'region_membre'=>'20',
              'departement_membre'=>'21',
              'zone_membre'=>'22',
              'localite_membre'=>'23',
              'type_membre'=>"2",
              'section'=>"S001-SISSEDOUGOU",
              'nom_comite_base'=>'',
              'nom'=>"SORO",
              'prenoms'=>'LOHOYIRIMEH',
              'date_naissance'=>'01/04/1992',
              'sexe'=>'M',
              'fonction'=>'12',
              'numero_pieces'=>'C0064977267',
              'numero_carte_militante'=>'',
              'contact'=>'79815420',
          );
         $this->RecensementModel->saveOperation("membres", $data);


        $i++;
      }

      die("Bon");
    }*/


    public function imprimeNoteSection()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }
      if(isset($_GET['region']) && isset($_GET['departement']) && isset($_GET['ss_zone']) && isset($_GET['localite']) && isset($_GET['nom_section']) && isset($_GET['nom_comite']))
      {  
         $region = $_GET['region'];
         $departement = $_GET['departement'];
         $ss_zone = $_GET['ss_zone'];
         $localite = $_GET['localite'];
         $nom_section = $_GET['nom_section'];
         $nom_comite = $_GET['nom_comite'];
         $this->data['listMembreSection']= $this->RecensementModel->selectMembre($region, $departement, $ss_zone, $localite, $nom_section, $nom_comite);
         
        // var_dump($this->data['listMembreSection']);die;
      }
      //$this->data['listMembreSection']= $this->RecensementModel->selectMembre(2);
      $this->load->view('imprime_note_section', $this->data);
    }

    public function imprimeNoteComite()
    {
      if(!$this->session->userdata("infoUser"))
      {
        redirect(site_url(), 'refresh');
      }
      $this->data['listMembreComite']= $this->RecensementModel->selectMembre(1);
      $this->load->view('imprime_note_comite', $this->data);
    }

}
